import React, { useState } from 'react';
// Asegúrate de que tu CSS se llame 'estilos.css' o ajusta esta línea
import './estilos.css'; 
import TockenService from '../services/tocken.js'; // El servicio de JWT

// Recibe 'setToken' desde App.js
function InicioLogin({ setToken }) { 
    // Declaración de estados de React (Correcto)
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null); 

    // Función de envío: SÍNCRONA, ya que TockenService.login es síncrona
    const handleSubmit = (e) => {
        e.preventDefault(); 
        setError(null); // Limpiar errores previos
        
        // 1. Llamada SÍNCRONA al servicio de login
        const result = TockenService.login(email, password); 

        if (result.success) {
            // 2. Si es exitoso, actualiza el estado global (App.js)
            setToken(result.token); 
        } else {
            // 3. Muestra el error si falla la autenticación
            setError(result.message);
        }
    };
    
    return (
        <div className="inicio-sesion"> 
            {/* Se conecta la función al formulario */}
            <form className="formulario" onSubmit={handleSubmit}>
                <h1>Iniciar Sesión</h1>

                {/* Mostrar error si existe */}
                {error && <p style={{ color: 'red', textAlign: 'center', marginTop: '10px' }}>{error}</p>}
                
                {/* Campo de Correo Electrónico */}
                <div className="datos">
                    <label htmlFor="email">Correo Electrónico:</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="tucorreo@ejemplo.com"
                        required
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                    /> 
                </div>

                {/* Campo de Contraseña */}
                <div className="datos">
                    <label htmlFor="password">Contraseña:</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Ingresa tu contraseña"
                        required
                        value={password} 
                        onChange={(e) => setPassword(e.target.value)} 
                    /> 
                </div>
                
                <button type="submit" className="boton-inicio">
                    Entrar
                </button>

                <p className="olvidar-contrasena">
                    {/* Usar <button> para accesibilidad si no hay URL real */}
                    <button type="button" style={{ background: 'none', border: 'none', color: '#007bff', cursor: 'pointer', padding: 0, textDecoration: 'underline' }}>
                      ¿Olvidaste tu contraseña?
                    </button>
                </p>
            </form>
        </div>
    );
}

export default InicioLogin;
