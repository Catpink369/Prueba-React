// src/components/catalogo.jsx
import React from "react";
import TockenService from "../services/tocken";
import "./catalogo.css";
import img1 from "../data/imagenes/1.png";
import img2 from "../data/imagenes/2.png";
import img3 from "../data/imagenes/3.png";


function Catalogo({ setToken }) {
  const userEmail = localStorage.getItem("userEmail");

  const handleLogout = () => {
    TockenService.logout();
    setToken(null);
  };

  const productos = [
    {
      id: 1,
      nombre: "Lápiz Labial",
      descripcion: "Color intenso y de larga duración.",
      precio: "$25.000",
      imagen: img1,
    },
    {
      id: 2,
      nombre: "Crema Hidratante",
      descripcion: "Ideal para piel seca, textura ligera.",
      precio: "$40.000",
      imagen: img2,
    },
    {
      id: 3,
      nombre: "Máscara de Pestañas",
      descripcion: "Volumen y definición sin grumos.",
      precio: "$30.000",
      imagen: img3,
    },
  ];

  return (
    <div className="catalogo-container">
      {/* HEADER */}
      <header className="catalogo-header">
        <h2 className="logo">/ᐠ - ˕ -マ Ⳋ</h2>
        <div className="user-actions">
          <span className="user-email">{userEmail || "Usuario"}</span>
          <button onClick={handleLogout} className="logout-button">
            Cerrar Sesión
          </button>
        </div>
      </header>

      {/* CONTENIDO PRINCIPAL */}
      <main className="catalogo-main">
        <h1>¡Bienvenido a tu Catálogo!</h1>
        <p className="user-info">Explora tus productos destacados.</p>

        <div className="productos-grid">
          {productos.map((p) => (
            <div key={p.id} className="producto-card">
              <img src={p.imagen} alt={p.nombre} />
              <h3>{p.nombre}</h3>
              <p className="descripcion">{p.descripcion}</p>
              <p className="precio">{p.precio}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

export default Catalogo;
