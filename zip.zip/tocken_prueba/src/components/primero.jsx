// src/components/Primero.jsx
import React from "react";
import "./primero.css";

function Primero({ setShowLogin }) {
  const handleStart = () => {
    setShowLogin(true);
  };

  return (
    <div className="hero-background">
      <div className="hero-card">
        <h1>¡Bienvenido!</h1>
        <p className="subtext">Esta es la pantalla de inicio.</p>
        <p className="descripcion">
          Pulsa el botón para ir a la página de <strong>Inicio de Sesión</strong>.
        </p>
        <button className="hero-button" onClick={handleStart}>
          Comenzar
        </button>
      </div>
    </div>
  );
}

export default Primero;
