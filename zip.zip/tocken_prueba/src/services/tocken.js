// src/services/tocken.js

// 1. Importa el JSON para simular la base de datos.
import users from '../data/users.json'; 

// La función de login es SÍNCRONA porque solo lee un archivo local.
const login = (email, password) => {
    
    // Buscar el usuario que coincida con el email Y la contraseña
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        // Simulación: Crear un token de prueba (FAKE JWT)
        const token = `fake-jwt-token-for-${user.id}-${Date.now()}`;

        // Almacenar los datos de la sesión en el navegador
        localStorage.setItem('userToken', token);
        localStorage.setItem('userEmail', user.email);

        // Devolver éxito
        return { success: true, token, email: user.email };
    } else {
        // Devolver fallo
        return { success: false, message: 'Credenciales inválidas. Por favor, verifica el usuario y contraseña.' };
    }
};

const getCurrentToken = () => {
    return localStorage.getItem('userToken');
};

const logout = () => {
    localStorage.removeItem('userToken');
    localStorage.removeItem('userEmail');
};

// Objeto de servicio para exportar
const TockenService = {
    login,
    getCurrentToken,
    logout
};

export default TockenService;