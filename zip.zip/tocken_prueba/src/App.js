// src/App.js (Versión corregida y limpia)

import React, { useState, useEffect } from 'react';
import TockenService from './services/tocken';
import Primero from './components/primero.jsx';
import InicioLogin from './components/inicio.jsx'; 
import Catalogo from './components/catalogo.jsx'; 

function App() {
    
    // 1. CORRECCIÓN: Usar getCurrentToken()
    const [token, setToken] = useState(TockenService.getCurrentToken());

    // 2. Estado para controlar la navegación: se inicia en FALSE para mostrar <Primero>
    const [showLogin, setShowLogin] = useState(false); 

    useEffect(() => {
        // Si ya hay un token al iniciar la app, saltamos la pantalla 'Primero'
        if (token) {
            setShowLogin(true);
        }
    }, [token]);


    // --- LÓGICA CONDICIONAL DE RENDERIZADO ---

    // A. Mostrar la pantalla de bienvenida (SOLO la primera vez, si showLogin es false)
    if (!showLogin) {
        // Al terminar, Primero debe llamar a setShowLogin(true)
        return <Primero setShowLogin={setShowLogin} />;
    }

    // B. Mostrar la vista protegida (si showLogin es true Y hay un token)
    if (token) {
        return <Catalogo setToken={setToken} />;
    }
    
    // C. Mostrar el formulario de Login (si showLogin es true PERO no hay token)
    // NOTA: Esta es la condición FINAL, no necesita chequear 'showLogin' de nuevo.
    return <InicioLogin setToken={setToken} />;
}

export default App;